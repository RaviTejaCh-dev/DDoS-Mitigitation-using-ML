echo "!!!!!...........Deploying Contracts............!!!"

node deployContract.js

echo "******* Adding IP addresses to Blockchain *******"

node index.js

echo "******* Blocking IP Addresses *******"

python3 ip_block.py

sudo cp ip_list.json /var/www/html/ip_list.json
