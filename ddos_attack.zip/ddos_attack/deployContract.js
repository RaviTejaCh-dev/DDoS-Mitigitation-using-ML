Web3 = require('web3');
web3 = new Web3(new Web3.providers.HttpProvider("http://127.0.0.1:8545"));
const { Console } = require('console');
const fs = require('fs');
code = fs.readFileSync('IpBlockchain.sol').toString();
solc = require('solc');
compiledCode = solc.compile(code);

abiDefinition = JSON.parse(compiledCode.contracts[':IpBlockchain'].interface)
const contractABI = abiDefinition;
const contractBytecode = compiledCode.contracts[':IpBlockchain'].bytecode;
const contract = new web3.eth.Contract(contractABI);
/*let ethereumAddress = web3.eth.getAccounts().then((accounts) =>{

    const firstAccount = accounts[0];
});*/
async function getEthereumAddress() {
    const accounts = await web3.eth.getAccounts();
    const ethereumAddress = accounts[0];
    return ethereumAddress;
  }
  
  (async () => {
    const ethereumAddress = await getEthereumAddress();
    //console.log(ethereumAddress);
    const deployTransaction = contract.deploy({data: contractBytecode}).send({from: ethereumAddress, gas: 4700000});
    async function deployContract() {
        try {
          const newContractInstance = await deployTransaction;
          console.log('Contract deployed at address :', newContractInstance.options.address);
          module.exports = newContractInstance.options.address;
        } catch (error) {
          console.error('Error deploying contract:', error);
        }
      }
      
      deployContract();
  })();
//console.log(ethereumAddress);
//const deployTransaction = contract.deploy({data: contractBytecode}).send({from: ethereumAddress, gas: 4700000});
/*deployTransaction.then(function(newContractInstance) {
  console.log('Contract deployed at:', newContractInstance.options.address);
  module.exports = newContractInstance.options.address;
});*/
/*async function deployContract() {
    try {
      const newContractInstance = await deployTransaction;
      console.log('Contract deployed at:', newContractInstance.options.address);
      module.exports = newContractInstance.options.address;
    } catch (error) {
      console.error('Error deploying contract:', error);
    }
  }
  
  deployContract(); */
  
/*const Web3 = require('web3');
const web3 = new Web3(new Web3.providers.HttpProvider('http://127.0.0.1:8545'));

const fs = require('fs');
const code = fs.readFileSync('Ip.sol').toString();
const solc = require('solc');
const compiledCode = solc.compile(code);

const abiDefinition = compiledCode.contracts[':Ip'] ? JSON.parse(compiledCode.contracts[':Ip'].interface) : null;

//const VotingContract = new web3.eth.Contract(abiDefinition);
const contractAddress = "0x02A894d5FFeFcD97E21BBb11bfd90F0ce8F536fd";
const myEthereumAddress = "0xfCB20B5da66A33A0F764794Dd2D76E0Ee91A857a";
const VotingContract = new web3.eth.Contract(abiDefinition, contractAddress, { from: myEthereumAddress });


const byteCode = compiledCode.contracts[':Ip'].bytecode;
const deployedContract = VotingContract.deploy({data: byteCode}).send({
  from: web3.eth.accounts[0],
  gas: 5000000
});

module.exports = deployedContract.then((instance) => instance.options.address);
*/