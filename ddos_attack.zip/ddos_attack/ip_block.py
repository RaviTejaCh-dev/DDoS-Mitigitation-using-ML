import subprocess
import time

def main():
    with open('ml_ip.txt') as f:
        for line in f:
            subprocess.run(["sudo iptables -A INPUT -s "+line[:-1]+" -j DROP"],shell=True)
            print(line[:-1] + " is blocked")
if __name__ == '__main__':
    main()
